"""
Own Merit - Incentive App Backend
Flask API with SQLite database, JWT auth, action logging, and voucher redemption.
"""

import sqlite3
import os
from datetime import timedelta

from flask import Flask, request, jsonify, g
from flask_cors import CORS
from flask_jwt_extended import (
    JWTManager,
    create_access_token,
    jwt_required,
    get_jwt_identity,
)
from werkzeug.security import generate_password_hash, check_password_hash

from mock_ai import generate_voucher

# ---------------------------------------------------------------------------
# App setup
# ---------------------------------------------------------------------------
app = Flask(__name__)
app.config["JWT_SECRET_KEY"] = "own-merit-dev-secret-change-in-prod"
app.config["JWT_ACCESS_TOKEN_EXPIRES"] = timedelta(days=7)

CORS(app, resources={r"/api/*": {"origins": "*"}})
jwt = JWTManager(app)

DATABASE = os.path.join(os.path.dirname(__file__), "ownmerit.db")

# ---------------------------------------------------------------------------
# Predefined action categories
# ---------------------------------------------------------------------------
ACTION_CATEGORIES = {
    "Energy Saving": {
        "points": 10,
        "actions": [
            "Turned off lights when leaving",
            "Used less heating",
            "Unplugged unused devices",
            "Air-dried laundry instead of tumble dryer",
            "Took a shorter shower",
        ],
    },
    "Property Cleanliness": {
        "points": 15,
        "actions": [
            "Cleaned communal area",
            "Reported maintenance issue",
            "Recycled waste properly",
            "Tidied front garden / entrance",
            "Disposed of bulky waste correctly",
        ],
    },
    "Community Participation": {
        "points": 20,
        "actions": [
            "Attended community event",
            "Helped a neighbour",
            "Volunteered for a local project",
            "Organised a community meetup",
            "Welcomed a new resident",
        ],
    },
}

VOUCHER_COST = 100  # points needed to redeem one voucher

# ---------------------------------------------------------------------------
# Database helpers
# ---------------------------------------------------------------------------

def get_db():
    """Get a database connection for the current request."""
    if "db" not in g:
        g.db = sqlite3.connect(DATABASE)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(exception):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    """Create tables if they don't exist."""
    db = sqlite3.connect(DATABASE)
    db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            total_points INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS actions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER REFERENCES users(id),
            category TEXT NOT NULL,
            action_name TEXT NOT NULL,
            points INTEGER NOT NULL,
            note TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS vouchers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER REFERENCES users(id),
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            code TEXT UNIQUE NOT NULL,
            points_cost INTEGER NOT NULL,
            status TEXT DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            expires_at TIMESTAMP
        );
    """)
    db.commit()
    db.close()


# ---------------------------------------------------------------------------
# Auth routes
# ---------------------------------------------------------------------------

@app.route("/api/register", methods=["POST"])
def register():
    data = request.get_json()
    name = data.get("name", "").strip()
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")

    if not name or not email or not password:
        return jsonify({"error": "Name, email, and password are required"}), 400

    if len(password) < 4:
        return jsonify({"error": "Password must be at least 4 characters"}), 400

    db = get_db()
    try:
        db.execute(
            "INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)",
            (name, email, generate_password_hash(password)),
        )
        db.commit()
    except sqlite3.IntegrityError:
        return jsonify({"error": "Email already registered"}), 409

    # Auto-login after register
    user = db.execute("SELECT id, name, email FROM users WHERE email = ?", (email,)).fetchone()
    token = create_access_token(identity=str(user["id"]))
    return jsonify({
        "token": token,
        "user": {"id": user["id"], "name": user["name"], "email": user["email"]},
    }), 201


@app.route("/api/login", methods=["POST"])
def login():
    data = request.get_json()
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")

    db = get_db()
    user = db.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()

    if user is None or not check_password_hash(user["password_hash"], password):
        return jsonify({"error": "Invalid email or password"}), 401

    token = create_access_token(identity=str(user["id"]))
    return jsonify({
        "token": token,
        "user": {
            "id": user["id"],
            "name": user["name"],
            "email": user["email"],
            "total_points": user["total_points"],
        },
    })


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------

@app.route("/api/dashboard", methods=["GET"])
@jwt_required()
def dashboard():
    user_id = int(get_jwt_identity())
    db = get_db()

    user = db.execute(
        "SELECT id, name, email, total_points FROM users WHERE id = ?", (user_id,)
    ).fetchone()

    if user is None:
        return jsonify({"error": "User not found"}), 404

    recent_actions = db.execute(
        "SELECT id, category, action_name, points, note, created_at "
        "FROM actions WHERE user_id = ? ORDER BY created_at DESC LIMIT 5",
        (user_id,),
    ).fetchall()

    voucher_count = db.execute(
        "SELECT COUNT(*) as cnt FROM vouchers WHERE user_id = ? AND status = 'active'",
        (user_id,),
    ).fetchone()["cnt"]

    return jsonify({
        "user": {
            "id": user["id"],
            "name": user["name"],
            "email": user["email"],
            "total_points": user["total_points"],
        },
        "recent_actions": [dict(a) for a in recent_actions],
        "voucher_cost": VOUCHER_COST,
        "active_vouchers": voucher_count,
    })


# ---------------------------------------------------------------------------
# Actions
# ---------------------------------------------------------------------------

@app.route("/api/actions/categories", methods=["GET"])
@jwt_required()
def get_categories():
    """Return all available action categories and their actions."""
    categories = []
    for cat_name, cat_data in ACTION_CATEGORIES.items():
        categories.append({
            "name": cat_name,
            "points": cat_data["points"],
            "actions": cat_data["actions"],
        })
    return jsonify({"categories": categories})


@app.route("/api/actions", methods=["POST"])
@jwt_required()
def log_action():
    user_id = int(get_jwt_identity())
    data = request.get_json()
    category = data.get("category", "")
    action_name = data.get("action_name", "")
    note = data.get("note", "")

    if category not in ACTION_CATEGORIES:
        return jsonify({"error": "Invalid category"}), 400

    if action_name not in ACTION_CATEGORIES[category]["actions"]:
        return jsonify({"error": "Invalid action for this category"}), 400

    points = ACTION_CATEGORIES[category]["points"]
    db = get_db()

    db.execute(
        "INSERT INTO actions (user_id, category, action_name, points, note) "
        "VALUES (?, ?, ?, ?, ?)",
        (user_id, category, action_name, points, note),
    )
    db.execute(
        "UPDATE users SET total_points = total_points + ? WHERE id = ?",
        (points, user_id),
    )
    db.commit()

    new_total = db.execute(
        "SELECT total_points FROM users WHERE id = ?", (user_id,)
    ).fetchone()["total_points"]

    return jsonify({
        "message": f"Logged: {action_name} (+{points} pts)",
        "points_earned": points,
        "total_points": new_total,
    }), 201


# ---------------------------------------------------------------------------
# Vouchers
# ---------------------------------------------------------------------------

@app.route("/api/vouchers", methods=["GET"])
@jwt_required()
def get_vouchers():
    user_id = int(get_jwt_identity())
    db = get_db()

    vouchers = db.execute(
        "SELECT id, title, description, code, points_cost, status, "
        "created_at, expires_at FROM vouchers WHERE user_id = ? "
        "ORDER BY created_at DESC",
        (user_id,),
    ).fetchall()

    return jsonify({"vouchers": [dict(v) for v in vouchers]})


@app.route("/api/vouchers/redeem", methods=["POST"])
@jwt_required()
def redeem_voucher():
    user_id = int(get_jwt_identity())
    db = get_db()

    user = db.execute(
        "SELECT total_points FROM users WHERE id = ?", (user_id,)
    ).fetchone()

    if user["total_points"] < VOUCHER_COST:
        return jsonify({
            "error": f"Not enough points. You need {VOUCHER_COST} but have {user['total_points']}."
        }), 400

    # Find the user's top category
    top_cat_row = db.execute(
        "SELECT category, COUNT(*) as cnt FROM actions "
        "WHERE user_id = ? GROUP BY category ORDER BY cnt DESC LIMIT 1",
        (user_id,),
    ).fetchone()

    top_category = top_cat_row["category"] if top_cat_row else None

    # Generate a voucher using mock AI
    voucher_data = generate_voucher(top_category)

    # Deduct points and save voucher
    db.execute(
        "UPDATE users SET total_points = total_points - ? WHERE id = ?",
        (VOUCHER_COST, user_id),
    )
    db.execute(
        "INSERT INTO vouchers (user_id, title, description, code, points_cost, expires_at) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (
            user_id,
            voucher_data["title"],
            voucher_data["description"],
            voucher_data["code"],
            VOUCHER_COST,
            voucher_data["expires_at"],
        ),
    )
    db.commit()

    new_total = db.execute(
        "SELECT total_points FROM users WHERE id = ?", (user_id,)
    ).fetchone()["total_points"]

    return jsonify({
        "message": "Voucher redeemed!",
        "voucher": voucher_data,
        "total_points": new_total,
    }), 201


# ---------------------------------------------------------------------------
# Run
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    init_db()
    print("Own Merit API running on http://localhost:5000")
    app.run(debug=True, port=5000)
