"""
Mock AI Voucher Generator
Picks personalized vouchers based on a resident's most-logged action category.
Designed to be easily swapped out for a real AI API (e.g. OpenAI) later.
"""

import random
import string
from datetime import datetime, timedelta

# Voucher templates grouped by dominant category
VOUCHER_CATALOG = {
    "energy": [
        {
            "title": "10% Utility Bill Discount",
            "description": "Save 10% on your next electricity or gas bill. "
                           "Reward for your energy-saving efforts!",
        },
        {
            "title": "Smart LED Bulb Pack",
            "description": "Redeem for a free pack of energy-efficient LED bulbs "
                           "at your local hardware store.",
        },
        {
            "title": "£5 Energy Store Credit",
            "description": "£5 credit toward smart plugs, thermostats, or other "
                           "energy-saving devices.",
        },
        {
            "title": "Free Home Energy Audit",
            "description": "Get a professional energy audit of your home to find "
                           "more ways to save.",
        },
    ],
    "cleanliness": [
        {
            "title": "Cleaning Supplies Voucher",
            "description": "£5 voucher for eco-friendly cleaning products at "
                           "participating stores.",
        },
        {
            "title": "Home Improvement Store Credit",
            "description": "£10 credit at your local home improvement store for "
                           "paint, tools, or supplies.",
        },
        {
            "title": "Free Garden Starter Kit",
            "description": "A starter kit with seeds, compost, and a planter to "
                           "brighten up your property.",
        },
        {
            "title": "Recycling Champion Badge",
            "description": "Exclusive digital badge plus a reusable shopping bag "
                           "set delivered to your door.",
        },
    ],
    "community": [
        {
            "title": "Restaurant Meal Voucher",
            "description": "Enjoy a free meal (up to £15) at a participating local "
                           "restaurant.",
        },
        {
            "title": "Cinema Ticket",
            "description": "One free cinema ticket at any participating cinema. "
                           "Popcorn not included!",
        },
        {
            "title": "Community Event VIP Pass",
            "description": "VIP access to the next community event, including "
                           "reserved seating.",
        },
        {
            "title": "Local Café Gift Card",
            "description": "£5 gift card for a local café. Perfect for a coffee "
                           "catch-up with neighbours.",
        },
    ],
}

# Map action categories to voucher catalog keys
CATEGORY_MAP = {
    "Energy Saving": "energy",
    "Property Cleanliness": "cleanliness",
    "Community Participation": "community",
}


def _generate_code(length=10):
    """Generate a random alphanumeric voucher code."""
    chars = string.ascii_uppercase + string.digits
    return "OWN-" + "".join(random.choices(chars, k=length))


def generate_voucher(top_category: str | None = None):
    """
    Generate a personalized voucher based on the resident's top category.

    Args:
        top_category: The category the resident logs most often
                      (e.g. "Energy Saving"). Falls back to random if None.

    Returns:
        dict with title, description, code, and expires_at
    """
    catalog_key = CATEGORY_MAP.get(top_category, None)

    if catalog_key is None:
        # Pick a random category if we don't know the resident's preference
        catalog_key = random.choice(list(VOUCHER_CATALOG.keys()))

    voucher_template = random.choice(VOUCHER_CATALOG[catalog_key])
    expires_at = datetime.utcnow() + timedelta(days=30)

    return {
        "title": voucher_template["title"],
        "description": voucher_template["description"],
        "code": _generate_code(),
        "expires_at": expires_at.isoformat(),
    }
