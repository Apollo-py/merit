import { Routes, Route, Navigate, NavLink, useLocation } from 'react-router-dom';
import { useAuth } from './AuthContext';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import LogAction from './pages/LogAction';
import Vouchers from './pages/Vouchers';

function TabBar() {
  return (
    <nav className="tab-bar">
      <NavLink to="/" end className={({ isActive }) => isActive ? 'active' : ''}>
        <span className="tab-icon">🏠</span>
        Home
      </NavLink>
      <NavLink to="/log" className={({ isActive }) => isActive ? 'active' : ''}>
        <span className="tab-icon">✅</span>
        Log
      </NavLink>
      <NavLink to="/vouchers" className={({ isActive }) => isActive ? 'active' : ''}>
        <span className="tab-icon">🎟️</span>
        Vouchers
      </NavLink>
    </nav>
  );
}

function ProtectedRoute({ children }) {
  const { token, loading } = useAuth();
  if (loading) return null;
  if (!token) return <Navigate to="/login" replace />;
  return children;
}

export default function App() {
  const { token, loading } = useAuth();
  const location = useLocation();
  const showTabs = token && location.pathname !== '/login';

  if (loading) return null;

  return (
    <div className="app-container">
      <Routes>
        <Route path="/login" element={
          token ? <Navigate to="/" replace /> : <Login />
        } />
        <Route path="/" element={
          <ProtectedRoute><Dashboard /></ProtectedRoute>
        } />
        <Route path="/log" element={
          <ProtectedRoute><LogAction /></ProtectedRoute>
        } />
        <Route path="/vouchers" element={
          <ProtectedRoute><Vouchers /></ProtectedRoute>
        } />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      {showTabs && <TabBar />}
    </div>
  );
}
