/**
 * API helper - handles all fetch requests to the Flask backend.
 * Automatically attaches JWT token from localStorage.
 */

const API_BASE = '/api';

async function request(endpoint, options = {}) {
  const token = localStorage.getItem('token');
  const headers = {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...options.headers,
  };

  const res = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers,
  });

  const data = await res.json();

  if (!res.ok) {
    throw new Error(data.error || 'Something went wrong');
  }

  return data;
}

// Auth
export const register = (name, email, password) =>
  request('/register', {
    method: 'POST',
    body: JSON.stringify({ name, email, password }),
  });

export const login = (email, password) =>
  request('/login', {
    method: 'POST',
    body: JSON.stringify({ email, password }),
  });

// Dashboard
export const getDashboard = () => request('/dashboard');

// Actions
export const getCategories = () => request('/actions/categories');

export const logAction = (category, action_name, note = '') =>
  request('/actions', {
    method: 'POST',
    body: JSON.stringify({ category, action_name, note }),
  });

// Vouchers
export const getVouchers = () => request('/vouchers');

export const redeemVoucher = () =>
  request('/vouchers/redeem', { method: 'POST' });
