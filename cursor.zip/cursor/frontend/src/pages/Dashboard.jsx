import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import { getDashboard } from '../api';

const CATEGORY_ICONS = {
  'Energy Saving': '⚡',
  'Property Cleanliness': '🧹',
  'Community Participation': '🤝',
};

const CATEGORY_CLASS = {
  'Energy Saving': 'energy',
  'Property Cleanliness': 'cleanliness',
  'Community Participation': 'community',
};

export default function Dashboard() {
  const { user, logout, updatePoints } = useAuth();
  const navigate = useNavigate();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchDashboard = async () => {
    try {
      const result = await getDashboard();
      setData(result);
      updatePoints(result.user.total_points);
    } catch (err) {
      if (err.message.includes('token') || err.message.includes('expired')) {
        logout();
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboard();
  }, []);

  if (loading) {
    return (
      <div className="page" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <p style={{ color: 'var(--text-secondary)' }}>Loading...</p>
      </div>
    );
  }

  const points = data?.user?.total_points || 0;
  const voucherCost = data?.voucher_cost || 100;
  const progress = Math.min((points % voucherCost) / voucherCost * 100, 100);
  const canRedeem = points >= voucherCost;

  return (
    <div className="page">
      <div className="page-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h1>Hello, {data?.user?.name?.split(' ')[0] || 'Resident'}!</h1>
          <p>Keep up the great work</p>
        </div>
        <button
          onClick={logout}
          style={{
            background: 'none',
            border: 'none',
            fontSize: '14px',
            color: 'var(--text-secondary)',
            cursor: 'pointer',
            fontFamily: 'inherit',
            fontWeight: 500,
          }}
        >
          Log out
        </button>
      </div>

      {/* Points Display */}
      <div className="points-display">
        <div className="points-value">{points}</div>
        <div className="points-label">Total Points</div>
      </div>

      {/* Progress to next voucher */}
      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '4px' }}>
          <span style={{ fontSize: '14px', fontWeight: 600 }}>Next Voucher</span>
          <span style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>
            {canRedeem ? 'Ready to redeem!' : `${points % voucherCost} / ${voucherCost} pts`}
          </span>
        </div>
        <div className="progress-bar">
          <div className="progress-fill" style={{ width: `${canRedeem ? 100 : progress}%` }} />
        </div>
        {canRedeem && (
          <button
            className="btn btn-success"
            style={{ marginTop: '12px' }}
            onClick={() => navigate('/vouchers')}
          >
            🎟️ Redeem Voucher
          </button>
        )}
      </div>

      {/* Quick Actions */}
      <h3 className="section-title">Quick Log</h3>
      <div className="quick-actions">
        <button className="quick-action-btn" onClick={() => navigate('/log?cat=Energy Saving')}>
          <span className="qa-icon">⚡</span>
          <span className="qa-label">Energy</span>
          <span className="qa-pts">+10 pts</span>
        </button>
        <button className="quick-action-btn" onClick={() => navigate('/log?cat=Property Cleanliness')}>
          <span className="qa-icon">🧹</span>
          <span className="qa-label">Cleanliness</span>
          <span className="qa-pts">+15 pts</span>
        </button>
        <button className="quick-action-btn" onClick={() => navigate('/log?cat=Community Participation')}>
          <span className="qa-icon">🤝</span>
          <span className="qa-label">Community</span>
          <span className="qa-pts">+20 pts</span>
        </button>
      </div>

      {/* Recent Activity */}
      <h3 className="section-title">Recent Activity</h3>
      <div className="card" style={{ padding: data?.recent_actions?.length ? '8px 16px' : '20px' }}>
        {!data?.recent_actions?.length ? (
          <div className="empty-state">
            <div className="empty-icon">📝</div>
            <h3>No activity yet</h3>
            <p>Start logging healthy behaviours to earn points!</p>
          </div>
        ) : (
          data.recent_actions.map((action) => (
            <div key={action.id} className="activity-item">
              <div className={`activity-icon ${CATEGORY_CLASS[action.category] || ''}`}>
                {CATEGORY_ICONS[action.category] || '✨'}
              </div>
              <div className="activity-details">
                <h4>{action.action_name}</h4>
                <p>{action.category}</p>
              </div>
              <span className="activity-points">+{action.points}</span>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
