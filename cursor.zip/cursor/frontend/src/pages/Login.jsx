import { useState } from 'react';
import { useAuth } from '../AuthContext';
import { login, register } from '../api';

export default function Login() {
  const { loginUser } = useAuth();
  const [isRegister, setIsRegister] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      let data;
      if (isRegister) {
        data = await register(name, email, password);
      } else {
        data = await login(email, password);
      }
      loginUser(data.user, data.token);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-logo">
        <div className="logo-icon">🏆</div>
        <h1>Own Merit</h1>
        <p>Track good habits, earn rewards</p>
      </div>

      <form className="auth-form" onSubmit={handleSubmit}>
        <h2 style={{ fontSize: '20px', fontWeight: 700, marginBottom: '20px', textAlign: 'center' }}>
          {isRegister ? 'Create Account' : 'Welcome Back'}
        </h2>

        {error && <div className="error-text">{error}</div>}

        {isRegister && (
          <div className="form-group">
            <label>Full Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter your name"
              required
            />
          </div>
        )}

        <div className="form-group">
          <label>Email</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            required
          />
        </div>

        <div className="form-group">
          <label>Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Enter password"
            required
            minLength={4}
          />
        </div>

        <button type="submit" className="btn btn-primary" disabled={loading}>
          {loading ? 'Please wait...' : (isRegister ? 'Create Account' : 'Log In')}
        </button>
      </form>

      <div className="auth-switch">
        {isRegister ? 'Already have an account? ' : "Don't have an account? "}
        <button onClick={() => { setIsRegister(!isRegister); setError(''); }}>
          {isRegister ? 'Log In' : 'Sign Up'}
        </button>
      </div>
    </div>
  );
}
