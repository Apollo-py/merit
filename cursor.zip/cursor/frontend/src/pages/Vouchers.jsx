import { useState, useEffect } from 'react';
import { useAuth } from '../AuthContext';
import { getVouchers, redeemVoucher, getDashboard } from '../api';

export default function Vouchers() {
  const { user, updatePoints } = useAuth();
  const [vouchers, setVouchers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [redeeming, setRedeeming] = useState(false);
  const [toast, setToast] = useState(null);
  const [points, setPoints] = useState(user?.total_points || 0);
  const voucherCost = 100;

  const fetchData = async () => {
    try {
      const [vData, dData] = await Promise.all([getVouchers(), getDashboard()]);
      setVouchers(vData.vouchers);
      setPoints(dData.user.total_points);
      updatePoints(dData.user.total_points);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleRedeem = async () => {
    setRedeeming(true);
    try {
      const result = await redeemVoucher();
      setToast({ type: 'success', message: `Voucher redeemed: ${result.voucher.title}` });
      setPoints(result.total_points);
      updatePoints(result.total_points);
      // Refresh vouchers list
      const vData = await getVouchers();
      setVouchers(vData.vouchers);
    } catch (err) {
      setToast({ type: 'error', message: err.message });
    } finally {
      setRedeeming(false);
      setTimeout(() => setToast(null), 4000);
    }
  };

  const canRedeem = points >= voucherCost;
  const activeVouchers = vouchers.filter((v) => v.status === 'active');
  const usedVouchers = vouchers.filter((v) => v.status !== 'active');

  if (loading) {
    return (
      <div className="page" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <p style={{ color: 'var(--text-secondary)' }}>Loading...</p>
      </div>
    );
  }

  return (
    <div className="page">
      {toast && <div className={`toast ${toast.type}`}>{toast.message}</div>}

      <div className="page-header">
        <h1>Vouchers</h1>
        <p>Redeem points for personalized rewards</p>
      </div>

      {/* Redeem section */}
      <div className="redeem-section">
        <h3>🎁 AI-Powered Rewards</h3>
        <p>
          {canRedeem
            ? `You have ${points} pts — enough to redeem!`
            : `You need ${voucherCost - points} more points to redeem (${points}/${voucherCost})`}
        </p>
        <button
          className="btn btn-primary"
          onClick={handleRedeem}
          disabled={!canRedeem || redeeming}
          style={{ maxWidth: '280px', margin: '0 auto' }}
        >
          {redeeming ? 'Generating voucher...' : `Redeem for ${voucherCost} pts`}
        </button>
      </div>

      {/* Active vouchers */}
      {activeVouchers.length > 0 && (
        <>
          <h3 className="section-title">Active Vouchers ({activeVouchers.length})</h3>
          {activeVouchers.map((v) => (
            <div key={v.id} className="voucher-card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div className="voucher-title">{v.title}</div>
                <span className="voucher-status active">Active</span>
              </div>
              <div className="voucher-desc">{v.description}</div>
              <div className="voucher-code">{v.code}</div>
              <div className="voucher-meta">
                <span>Cost: {v.points_cost} pts</span>
                <span>Expires: {v.expires_at ? new Date(v.expires_at).toLocaleDateString() : 'N/A'}</span>
              </div>
            </div>
          ))}
        </>
      )}

      {/* Used / expired vouchers */}
      {usedVouchers.length > 0 && (
        <>
          <h3 className="section-title" style={{ marginTop: '8px' }}>Past Vouchers</h3>
          {usedVouchers.map((v) => (
            <div key={v.id} className="voucher-card used">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div className="voucher-title">{v.title}</div>
                <span className="voucher-status used">Used</span>
              </div>
              <div className="voucher-desc">{v.description}</div>
              <div className="voucher-code">{v.code}</div>
            </div>
          ))}
        </>
      )}

      {/* Empty state */}
      {vouchers.length === 0 && (
        <div className="empty-state">
          <div className="empty-icon">🎟️</div>
          <h3>No vouchers yet</h3>
          <p>Keep logging healthy behaviours to earn points and unlock personalised rewards!</p>
        </div>
      )}
    </div>
  );
}
