import { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import { getCategories, logAction } from '../api';

const CATEGORY_ICONS = {
  'Energy Saving': '⚡',
  'Property Cleanliness': '🧹',
  'Community Participation': '🤝',
};

export default function LogAction() {
  const { updatePoints } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const preselectedCat = searchParams.get('cat');

  const [categories, setCategories] = useState([]);
  const [selectedCat, setSelectedCat] = useState(preselectedCat || '');
  const [selectedAction, setSelectedAction] = useState('');
  const [note, setNote] = useState('');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [toast, setToast] = useState(null);

  useEffect(() => {
    getCategories()
      .then((data) => {
        setCategories(data.categories);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const handleSubmit = async () => {
    if (!selectedCat || !selectedAction) return;
    setSubmitting(true);
    try {
      const result = await logAction(selectedCat, selectedAction, note);
      updatePoints(result.total_points);
      setToast({ type: 'success', message: result.message });
      // Reset form
      setSelectedAction('');
      setNote('');
      // Navigate back to dashboard after short delay
      setTimeout(() => {
        navigate('/');
      }, 1500);
    } catch (err) {
      setToast({ type: 'error', message: err.message });
    } finally {
      setSubmitting(false);
      setTimeout(() => setToast(null), 3000);
    }
  };

  const currentCategory = categories.find((c) => c.name === selectedCat);

  if (loading) {
    return (
      <div className="page" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <p style={{ color: 'var(--text-secondary)' }}>Loading...</p>
      </div>
    );
  }

  return (
    <div className="page">
      {toast && <div className={`toast ${toast.type}`}>{toast.message}</div>}

      <div className="page-header">
        <h1>Log Action</h1>
        <p>Choose a category and action to earn points</p>
      </div>

      {/* Step 1: Pick category */}
      <h3 className="section-title">1. Choose Category</h3>
      {categories.map((cat) => (
        <div
          key={cat.name}
          className={`category-card ${selectedCat === cat.name ? 'selected' : ''}`}
          onClick={() => {
            setSelectedCat(cat.name);
            setSelectedAction('');
          }}
        >
          <div className="cat-header">
            <h3>{CATEGORY_ICONS[cat.name] || '✨'} {cat.name}</h3>
            <span className="cat-points">+{cat.points} pts</span>
          </div>
          <div className="cat-desc">
            {cat.actions.length} actions available
          </div>
        </div>
      ))}

      {/* Step 2: Pick action */}
      {selectedCat && currentCategory && (
        <>
          <h3 className="section-title" style={{ marginTop: '8px' }}>2. Choose Action</h3>
          {currentCategory.actions.map((action) => (
            <div
              key={action}
              className={`action-item ${selectedAction === action ? 'selected' : ''}`}
              onClick={() => setSelectedAction(action)}
            >
              <div className="action-icon">
                {selectedAction === action ? '✅' : '⭕'}
              </div>
              <div className="action-info">
                <h4>{action}</h4>
              </div>
            </div>
          ))}
        </>
      )}

      {/* Step 3: Optional note + submit */}
      {selectedAction && (
        <>
          <h3 className="section-title" style={{ marginTop: '8px' }}>3. Add Note (optional)</h3>
          <div className="form-group">
            <textarea
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Any additional details..."
              rows={3}
              style={{ resize: 'vertical' }}
            />
          </div>

          <button
            className="btn btn-primary"
            onClick={handleSubmit}
            disabled={submitting}
          >
            {submitting ? 'Logging...' : `Log Action (+${currentCategory.points} pts)`}
          </button>
        </>
      )}
    </div>
  );
}
